//
//  ViewController.swift
//  TouchEvent
//
//  Created by syed fazal abbas on 10/05/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var vw: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("Touches Began")
        if let  touch = touches.first{
            if vw == touch.view{
                vw.backgroundColor = UIColor.yellow
            }
            else{
                vw.backgroundColor = UIColor.purple
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first{
            if vw == touch.view{
                vw.backgroundColor = UIColor.green
            }
            else{
                vw.backgroundColor = UIColor.blue
            }
        }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("Touch Ended")
    }
}

